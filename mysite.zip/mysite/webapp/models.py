from django.db import models

class User(models.Model):
    userName = models.CharField(max_length=10)
    userDOB = models.IntegerField()
    userContact = models.IntegerField()



    def __str__(self):
        return self.userName




# Create your models here.
